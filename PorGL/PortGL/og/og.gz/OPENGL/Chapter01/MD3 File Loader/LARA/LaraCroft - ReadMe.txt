<October 3, 2001>
=================================================================================

Model Name:		Lara Croft

Installation Directory:	baseq3\md3-laracroft.pk3

Model Author:		PornStar		
			nickelbag@nyc.com

Skin Author:		PornStar

Additional Misc. Help:	James "_Goatman_" Gatzmer

Animations, Sounds
bots & LOD's:		James "_Goatman_" Gatzmer
			goatman@ironsnackcracker.com
			http://www.ironsnackcracker.com/		

Contact:		Pornstar
			nickelbag@nyc.com

=================================================================================

Model description:	yep... i based this model off angelina jolie from that
			tomb raider movie.. ehh movie was okay... anyway i really
			tried to make the model as realistic as possible.. i'm pretty
			proud of the skin which is where most the realism is.. The skins
			are all basically variations of each other in some way... i kinda
			have an block on my imagination so... oh well... comments what not,
			mail to nickelbag@nyc.com...

Big Ups:		big ups to ocelot, the mighty pea... huge up to goatman...
			ahh feck, if its mad late
			and i wanna finish this thing up before i go to sleep so if i 
			missed anybody my fault..
	

=================================================================================
_Goatman_ info:
	 I wanted to take this opportunity to go back to the basics on this
model.  I've experimented with adding a little more weight and secondary motion.
The only minor issue is the swaying of the torso, but when I scale it back, it's
looses a lot in my opinion.
	Bots are pretty straight forward... Preference on the rocket launcher and
BFG, easy on easy, not so easy on nightmare.
	Sounds were captured from Tomb Raider 3.  I modified and manipulated some
of the more fitting ones for the context of Quake.

=================================================================================

Other info:		pornstar says whats up..
	

=================================================================================
"Game Info"

Construction:
Poly Count              :  1571 for high
			   1207 for medium
			   841 for low
Vert Count              :  1182 for high
			   969 for medium
			   718 for low
Skin Count              :  6 with CTF skins.


Software used:

Tweaked and animated in 3D Studio MAX 4.0 - http://www.discreet.com -
	with Character Studio and a bones/ik chain on the hair
Exported with pop n' fresh's MAX plugin - pop_n_fresh@telus.net and Rodolpho
	Cazabon
Recompiled in Npherno's MD3 Compiler - npherno@sunstorm.net
Bots by BotStudio v. 0.98 - doktor@cutey.com - 
	http://www.planetquake.com/botstudio
Photoshop 6.0 was used for the textures - http://www.adobe.com
SoundForge 5 for the audio - http://www.sonicfoundry.com

Installation:
	Just put the md3-laracroft.pk3 file in your \baseq3 folder.

=================================================================================

_Goatman wishes to thank:
	id software, pop n fresh for his exporter, Npherno for his compiler, the
folks in #model_design and the folks at www.polycount.com, especially rogue13, for
all his great work efforts in the community.
Groove is in the heart.

=================================================================================

* Copyright / Permissions *
	QUAKE(R) and QUAKE III Arena(R) are registered trademarks of id Software,
		 Inc.
	Lara Croft is a character from the Eidos/CORE game.  All rights reserved.
	Please don't sue us.


This model may be freely distributed in any form, UNALTERED, which means, you can't
remove/change the readme file, other files, or add your own stuff to it and pass it
along.